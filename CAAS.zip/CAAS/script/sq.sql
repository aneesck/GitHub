CREATE TABLE `caas`.`caas_user` (
  `user_id` VARCHAR(10) BINARY NOT NULL DEFAULT '',
  `user_name` VARCHAR(45) NOT NULL DEFAULT '',
  `user_role` INTEGER UNSIGNED NOT NULL DEFAULT 0,
  `created_date` DATETIME NOT NULL DEFAULT 0,
  PRIMARY KEY(`user_id`)
)
ENGINE = InnoDB;


CREATE TABLE `caas`.`caas_role` (
  `role_id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(45) NOT NULL DEFAULT '',
  PRIMARY KEY(`role_id`)
)
ENGINE = InnoDB;


CREATE TABLE `caas`.`caas_member` (
  `member_id` VARCHAR(10) NOT NULL DEFAULT '',
  `member_name` VARCHAR(45) NOT NULL DEFAULT '',
  `member_dob` DATETIME NOT NULL DEFAULT 0,
  `member_address` VARCHAR(2555) NOT NULL DEFAULT '',
  `member_phone` NUMERIC NOT NULL DEFAULT 0,
  PRIMARY KEY(`member_id`)
)
ENGINE = InnoDB;

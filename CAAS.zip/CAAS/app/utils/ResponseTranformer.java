package utils;

import java.util.ArrayList;
import java.util.List;

import models.Master;
import models.MasterMap;

public class ResponseTranformer {

	public static List<Master> transformInput(List<MasterMap> masterMaps){
		
List<Master> masters=new ArrayList<Master>(); 
		
		for (MasterMap masterMap2 : masterMaps) {
			masters.add(masterMap2.master);
		}
		
		return masters;
		
	}
	
}

package controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import models.Master;
import models.MasterMap;
import models.StudentMember;
import models.persistant.MasterMapPersistant;
import models.persistant.MemberPersistant;
import models.persistant.StudentPersistant;
import play.*;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.*;

import utils.ResponseTranformer;
import views.html.*;

public class Application extends Controller {

	@Transactional
    public static Result index() {
		 response().setHeader("Access-Control-Allow-Origin", "http://localhost:8080");       // Need to add the correct domain in here!!
		    response().setHeader("Access-Control-Allow-Methods", "POST");   // Only allow POST
		    response().setHeader("Access-Control-Max-Age", "300");          // Cache response for 5 minutes
		    response().setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");  
        return ok(index.render(StudentMember.findById("1001").memberPhone));
    }
	
	
	@Transactional
	public static Result createMaster(){
		Master master = Json.fromJson(request().body().asJson(), Master.class);
		master.save();
		return ok();
	}
	
	@Transactional
	public static Result createStudent(){
		StudentMember student= Json.fromJson(request().body().asJson(), StudentMember.class);
		student.save();
		return ok();
	}
    
	
	@Transactional
    public static Result index1() {
		
		MemberPersistant member= Json.fromJson(request().body().asJson().get("member"), MemberPersistant.class);
		List<StudentPersistant> demo=null;
		//List<StudentPersistant> students= Json.fromJson(request().body().asJson().findValues("student"), List.class);
		List<StudentPersistant> students=new ArrayList<StudentPersistant>();
		
		Iterator<JsonNode> iterator=request().body().asJson().findValues("student").get(0).iterator();
		
		while(iterator.hasNext()){
			
			JsonNode jsonNode=iterator.next();
			
			students.add(Json.fromJson(jsonNode, StudentPersistant.class));
		}
		for (StudentPersistant studentPersistant : students) {
			studentPersistant.save();
		}
		/*member.memberAddress="Haseena Manzil";
		member.memberDob="1989-09-07";
		member.memberId="1234";
		member.memberName="Anees";
		member.memberPhone="7353417555";
		StudentPersistant master=new StudentPersistant();
		master.id="1234";
		master.propertId=1;
		master.value="8045";
		master.save();*/
		member.save();
		
        return ok(Json.toJson(StudentMember.findById("1001")));
    }
    
	@Transactional
	public static Result getForm(String name){
		MasterMap masterMap=new MasterMap();
		List<MasterMap> studentFormList=masterMap.getMapFor(name);
		return ok(Json.toJson(ResponseTranformer.transformInput(studentFormList)));
	}
    
	
	@Transactional
    public static Result addProperty() {
		Master master= Json.fromJson(request().body().asJson(), Master.class);
		MasterMapPersistant mapPersistant=new MasterMapPersistant();
		mapPersistant.priority=0;
		mapPersistant.propertyId=master.id;
		mapPersistant.required=false;
		mapPersistant.tableName="caas_student";
		mapPersistant.save();
		master.save();
		
        return ok(Json.toJson(StudentMember.findById("1001")));
    }
	

}

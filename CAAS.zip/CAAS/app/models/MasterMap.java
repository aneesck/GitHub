package models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import play.db.jpa.JPA;

@Entity
@Table(name="caas_master_map")

public class MasterMap {
	@Id
	@Column(name="property_id")
	public int propertyId;
	
	@Column(name="table_name")
	public String tableName;
	
	@Column(name="priority")
	public int priority;
	
	public boolean required;
	
	@OneToOne
	@JoinColumn(name="property_id")
	public Master master;
	
	public List<MasterMap> getMapFor(String filter){
		
		@SuppressWarnings("unchecked")
		List<MasterMap> resultMap=JPA.em().createQuery("from MasterMap map where lower(map.tableName) like ? ")
        .setParameter(1, "%" + filter.toLowerCase() + "%")
        .getResultList();
		
		return resultMap;
		
	}
	
	public void save(){
		JPA.em().persist(this);
	}
	
}

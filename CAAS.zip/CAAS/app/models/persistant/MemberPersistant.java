package models.persistant;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import models.StudentMaster;
import play.db.jpa.JPA;

@Entity
@Table(name="caas_member")
public class MemberPersistant implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="member_id")
	public String memberId;

	@Column(name="member_name")
	public String memberName;

	@Column(name="member_dob")
	public String memberDob;
	
	@Column(name="member_address")
	public String memberAddress;
	
	@Column(name="member_phone")
	public String memberPhone;
	
	 public static MemberPersistant findById(String i) {
		 	System.out.println(JPA.em().getProperties());
		 	MemberPersistant student=new MemberPersistant();
		 	student.memberId="1001";
	        return JPA.em().find(MemberPersistant.class, "1001");
	    }
	
	 public void save(){
		 JPA.em().persist(this);
		 
	 }
	 
	
}
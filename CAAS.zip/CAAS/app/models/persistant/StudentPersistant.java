package models.persistant;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import play.db.jpa.JPA;

@Entity
@Table(name="caas_student")
public class StudentPersistant implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3L;

	@Id
	public String id;
	
	@Column(name="property_id")
	@Id
	public int propertyId;
	
	public String value;
	
	public static StudentPersistant findById(String id) {
        return JPA.em().find(StudentPersistant.class, id);
    }
	
	public void save(){
		JPA.em().persist(this);
		//JPA.em().merge(this);
	}

	
}
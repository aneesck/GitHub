package models.persistant;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import models.Master;
import models.MasterMap;
import play.db.jpa.JPA;

@Entity
@Table(name="caas_master_map")
public class MasterMapPersistant {

	@Id
	@Column(name="property_id")
	public int propertyId;
	
	@Column(name="table_name")
	public String tableName;
	
	@Column(name="priority")
	public int priority;
	
	public boolean required;
	
	public void save(){
		JPA.em().persist(this);
	}
	
}

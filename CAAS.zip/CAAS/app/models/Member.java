package models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import play.data.format.Formats;
import play.db.jpa.JPA;

@Entity
@Table(name="caas_member")
public class Member implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="member_id")
	public String memberId;
	
	@Column(name="member_name")
	public String memberName;
	
	@Formats.DateTime(pattern="yyyy-MM-dd")
	@Column(name="member_dob")
	public Date memberDob;
	
	@Column(name="member_address")
	public String memberAddress;
	
	@Column(name="member_phone")
	public String memberPhone;
	
	public static Member findById(String id) {
        return JPA.em().find(Member.class, id);
    }

	
}

package models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import play.db.jpa.*;


@Entity
@Table(name="caas_member")
public class StudentMember implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="member_id")
	public String memberId;

	@Column(name="member_name")
	public String memberName;

	@Column(name="member_dob")
	public String memberDob;
	
	@Column(name="member_address")
	public String memberAddress;
	
	@Column(name="member_phone")
	public String memberPhone;
	
	@OneToMany
	@JoinColumn(name="id")
	public List<StudentMaster> student;
	
	 public static StudentMember findById(String i) {
		 	System.out.println(JPA.em().getProperties());
		 	StudentMember student=new StudentMember();
		 	student.memberId="1001";
	        return JPA.em().find(StudentMember.class, "1001");
	    }
	
	 public void save(){
		 JPA.em().persist(this);
		 
	 }
	 
	
}

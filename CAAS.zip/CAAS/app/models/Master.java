package models;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import play.db.jpa.JPA;

@Entity
@Table(name="caas_master")
@JsonAutoDetect
public class Master {

	@Id
	public int id;
	
	public String name;
	
	@Column(name="data_type")
	public String dataType;
	
	public String label;
	
	public void save(){
		JPA.em().persist(this);
	}

	
}

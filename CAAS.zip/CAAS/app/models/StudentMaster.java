package models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import play.db.jpa.JPA;

@Entity
@Table(name="caas_student")
public class StudentMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	@Id
	public String id;
	
	@Column(name="property_id")
	@Id
	public int propertId;
	
	public String value;
	
	@OneToOne
	@JoinColumn(name="property_id")
	public Master master;
	
	
	public static StudentMaster findById(String id) {
        return JPA.em().find(StudentMaster.class, id);
    }

	
}
